import java.util.Objects;

public class Dimensao {
    private double largura;
    private double altura;
    private double comprimento;

    public Dimensao() {}

    public Dimensao(double largura, double altura, double comprimento) {
        this.largura = largura;
        this.altura = altura;
        this.comprimento = comprimento;
    }

    public double getLargura() {
        return largura;
    }

    public void setLargura(double largura) {
        this.largura = largura;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getComprimento() {
        return comprimento;
    }

    public void setComprimento(double comprimento) {
        this.comprimento = comprimento;
    }

    public double getArea(){
        return largura*altura*comprimento;
    }

    @Override
    public boolean equals(Object o) {

        if (o == null || getClass() != o.getClass()) return false;
        Dimensao dimensao = (Dimensao) o;
        return Double.compare(getLargura(), dimensao.getLargura()) == 0 && Double.compare(getAltura(), dimensao.getAltura()) == 0 && Double.compare(getComprimento(), dimensao.getComprimento()) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getLargura(), getAltura(), getComprimento());
    }

    @Override
    public String toString() {
        return "Dimensao{" +
                "largura=" + largura +
                ", altura=" + altura +
                ", comprimento=" + comprimento +
                '}';
    }
}

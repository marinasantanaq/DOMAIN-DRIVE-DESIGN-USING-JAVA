public class Encomenda {
    private Ponto remetente;
    private Ponto destinatario;

    public Encomenda(){}

    public Encomenda(Ponto remetente, Ponto destinatario) {
        this.remetente = remetente;
        this.destinatario = destinatario;
    }

    public Ponto getRemetente() {
        return remetente;
    }

    public void setRemetente(Ponto remetente) {
        this.remetente = remetente;
    }

    public Ponto getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(Ponto destinatario) {
        this.destinatario = destinatario;
    }

    @Override
    public String toString() {
        return "Encomenda{" +
                "remetente=" + remetente +
                ", destinatario=" + destinatario +
                '}';
    }
}

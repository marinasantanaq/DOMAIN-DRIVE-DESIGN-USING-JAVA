import java.util.Objects;

public class Ponto {
    public String nome;
    public String endereco;

    public Ponto(){}

    public Ponto(String nome, String endereco) {
        this.nome = nome; this.endereco = endereco;
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getEndereco() {
        return endereco;
    }
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Ponto ponto = (Ponto) o;
        return Objects.equals(getNome(), ponto.getNome()) && Objects.equals(getEndereco(), ponto.getEndereco());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNome(), getEndereco());
    }

    @Override
    public String toString() {
        return "Ponto{" +
                "nome='" + nome + '\'' +
                ", endereco='" + endereco + '\'' +
                '}';
    }
}

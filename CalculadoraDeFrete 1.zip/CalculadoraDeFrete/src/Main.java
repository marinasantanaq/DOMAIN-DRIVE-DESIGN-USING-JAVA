void main() {
    var novoPacote = new Pacote(); //declarei um novo pacote
    novoPacote.setDimensao(new Dimensao(7.80, 16.34, 0.875)); //setei as dimensoes do novo pacote
    //IO.println(novoPacote.getDimensao().getArea()); // apresentei o calculo da area dele
    //novoPacote.getDimensao().setLargura(8); // alterei a largura
    //IO.println(novoPacote.getDimensao().getArea());//apresentar o calculo da area novamente

    novoPacote.setPesoEmkg(0.231);
    novoPacote.setEhFragil(false);
    novoPacote.setRemetente(new Ponto("Leonardo", "Av. Paulista, 2000"));
    novoPacote.setDestinatario(new Ponto("Paulo", "Av. Faria Lima, 900"));

    IO.println(novoPacote);
}

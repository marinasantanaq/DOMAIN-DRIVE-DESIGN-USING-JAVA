import java.util.Objects;

public class Transporte {
    private String marca;
    private String modelo;
    private String placa;
    private int capacidadeEmKg;
    private int capacidadeEmL;

    public Transporte() {}

    public Transporte(String marca, String modelo, String placa, int capacidadeEmKg, int capacidadeEmL) {
        this.marca = marca;
        this.modelo = modelo;
        this.placa = placa;
        this.capacidadeEmKg = capacidadeEmKg;
        this.capacidadeEmL = capacidadeEmL;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public int getCapacidadeEmKg() {
        return capacidadeEmKg;
    }

    public void setCapacidadeEmKg(int capacidadeEmKg) {
        this.capacidadeEmKg = capacidadeEmKg;
    }

    public int getCapacidadeEmL() {
        return capacidadeEmL;
    }

    public void setCapacidadeEmL(int capacidadeEmL) {
        this.capacidadeEmL = capacidadeEmL;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Transporte that = (Transporte) o;
        return getCapacidadeEmKg() == that.getCapacidadeEmKg() && getCapacidadeEmL() == that.getCapacidadeEmL() && Objects.equals(getMarca(), that.getMarca()) && Objects.equals(getModelo(), that.getModelo()) && Objects.equals(getPlaca(), that.getPlaca());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getMarca(), getModelo(), getPlaca(), getCapacidadeEmKg(), getCapacidadeEmL());
    }

    @Override
    public String toString() {
        return "Transporte{" +
                "marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", placa='" + placa + '\'' +
                ", capacidadeEmKg=" + capacidadeEmKg +
                ", capacidadeEmL=" + capacidadeEmL +
                '}';
    }
}

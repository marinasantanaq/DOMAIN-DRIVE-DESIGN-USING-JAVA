import java.util.Objects;

public class Pacote extends Encomenda {
    private Dimensao dimensao;
    private double pesoEmkg;
    private boolean ehFragil;

    public Pacote(){}

    public Pacote(Dimensao dimensao, double pesoEmkg, boolean ehFragil) {
        this.dimensao = dimensao;
        this.pesoEmkg = pesoEmkg;
    }

    public Dimensao getDimensao() {
        return dimensao;
    }

    public void setDimensao(Dimensao dimensao) {
        this.dimensao = dimensao;
    }

    public double getPesoEmkg() {
        return pesoEmkg;
    }

    public void setPesoEmkg(double pesoEmkg) {
        this.pesoEmkg = pesoEmkg;
    }

    public boolean ehFragil() {
        return ehFragil;
    }

    public void setEhFragil(boolean ehFragil) {
        this.ehFragil = ehFragil;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Pacote pacote = (Pacote) o;
        return Objects.equals(getDimensao(), pacote.getDimensao());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getDimensao());
    }

    @Override
    public String toString() {
        return "Pacote{" +
                "dimensao=" + dimensao +
                ", pesoEmkg=" + pesoEmkg +
                ", ehFragil=" + ehFragil +
                "} " + super.toString();
    }
}

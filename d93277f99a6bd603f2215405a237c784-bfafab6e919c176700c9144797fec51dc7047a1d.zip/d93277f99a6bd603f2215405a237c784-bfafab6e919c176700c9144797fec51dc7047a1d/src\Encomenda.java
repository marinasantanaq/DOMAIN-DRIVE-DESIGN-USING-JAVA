
    public class Encomenda {
        private Local remetente;
        private Local destiantario;
    }



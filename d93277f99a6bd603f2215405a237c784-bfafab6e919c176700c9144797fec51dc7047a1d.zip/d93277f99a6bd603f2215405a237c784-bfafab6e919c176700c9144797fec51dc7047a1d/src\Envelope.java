public class Envelope extends {

}
